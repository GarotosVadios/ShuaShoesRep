package shuashoes;

public class SizeConversion {

    public static double convertCmToBr(double cm) {
        return cm * 1.5 + 22; // Exemplo fictício
    }

    public static double convertCmToUk(double cm) {
        return cm * 0.5 + 2; // Exemplo fictício
    }

    public static double convertCmToUsa(double cm) {
        return cm * 0.75 + 4; // Exemplo fictício
    }
}
