package shuashoes;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class UserDAO {

    public void addUser(User user) {
        try (Connection conn = DBConnection.getConnection()) {
            String sql = "INSERT INTO perfil_usuario (nome, email, senha, cpf, endereco, tamanho_padrao) VALUES (?, ?, ?, ?, ?, ?)";
            PreparedStatement statement = conn.prepareStatement(sql);
            statement.setString(1, user.getNome());
            statement.setString(2, user.getEmail());
            statement.setString(3, user.getSenha());
            statement.setString(4, user.getCpf());
            statement.setString(5, user.getEndereco());
            statement.setDouble(6, user.getTamanhoPadrao());
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<User> getAllUsers() {
        List<User> users = new ArrayList<>();
        try (Connection conn = DBConnection.getConnection()) {
            String sql = "SELECT * FROM perfil_usuario";
            Statement statement = conn.createStatement();
            ResultSet resultSet = statement.executeQuery(sql);
            while (resultSet.next()) {
                User user = new User();
                user.setId(resultSet.getInt("id"));
                user.setNome(resultSet.getString("nome"));
                user.setEmail(resultSet.getString("email"));
                user.setSenha(resultSet.getString("senha"));
                user.setCpf(resultSet.getString("cpf"));
                user.setEndereco(resultSet.getString("endereco"));
                user.setTamanhoPadrao(resultSet.getDouble("tamanho_padrao"));
                users.add(user);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return users;
    }

    public void updateUser(User user) {
        try (Connection conn = DBConnection.getConnection()) {
            String sql = "UPDATE perfil_usuario SET nome=?, email=?, senha=?, cpf=?, endereco=?, tamanho_padrao=? WHERE id=?";
            PreparedStatement statement = conn.prepareStatement(sql);
            statement.setString(1, user.getNome());
            statement.setString(2, user.getEmail());
            statement.setString(3, user.getSenha());
            statement.setString(4, user.getCpf());
            statement.setString(5, user.getEndereco());
            statement.setDouble(6, user.getTamanhoPadrao());
            statement.setInt(7, user.getId());
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deleteUser(int userId) {
        try (Connection conn = DBConnection.getConnection()) {
            String sql = "DELETE FROM perfil_usuario WHERE id=?";
            PreparedStatement statement = conn.prepareStatement(sql);
            statement.setInt(1, userId);
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
