package shuashoes;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        UserDAO userDAO = new UserDAO();
        Scanner scanner = new Scanner(System.in);
        int option;

        do {
            System.out.println("Selecione uma opção:");
            System.out.println("1. Adicionar usuário");
            System.out.println("2. Listar todos os usuários");
            System.out.println("3. Atualizar usuário");
            System.out.println("4. Deletar usuário");
            System.out.println("5. Converter tamanho em cm para BR, UK, USA");
            System.out.println("0. Sair");
            option = scanner.nextInt();
            scanner.nextLine(); // Consumir nova linha

            switch (option) {
                case 1:
                    System.out.print("Nome: ");
                    String nome = scanner.nextLine();
                    System.out.print("Email: ");
                    String email = scanner.nextLine();
                    System.out.print("Senha: ");
                    String senha = scanner.nextLine();
                    System.out.print("CPF: ");
                    String cpf = scanner.nextLine();
                    System.out.print("Endereço: ");
                    String endereco = scanner.nextLine();
                    System.out.print("Tamanho Padrão: ");
                    double tamanho = scanner.nextDouble();
                    User user = new User(nome, email, senha, cpf, endereco, tamanho);
                    userDAO.addUser(user);
                    System.out.println("Usuário adicionado com sucesso!");
                    break;

                case 2:
                    List<User> users = userDAO.getAllUsers();
                    for (User u : users) {
                        System.out.println(u);
                    }
                    break;

                case 3:
                    System.out.print("ID do usuário a ser atualizado: ");
                    int updateId = scanner.nextInt();
                    scanner.nextLine();
                    System.out.print("Novo Nome: ");
                    nome = scanner.nextLine();
                    System.out.print("Novo Email: ");
                    email = scanner.nextLine();
                    System.out.print("Nova Senha: ");
                    senha = scanner.nextLine();
                    System.out.print("Novo CPF: ");
                    cpf = scanner.nextLine();
                    System.out.print("Novo Endereço: ");
                    endereco = scanner.nextLine();
                    System.out.print("Novo Tamanho Padrão: ");
                    tamanho = scanner.nextDouble();
                    User updateUser = new User(nome, email, senha, cpf, endereco, tamanho);
                    updateUser.setId(updateId);
                    userDAO.updateUser(updateUser);
                    System.out.println("Usuário atualizado com sucesso!");
                    break;

                case 4:
                    System.out.print("ID do usuário a ser deletado: ");
                    int deleteId = scanner.nextInt();
                    userDAO.deleteUser(deleteId);
                    System.out.println("Usuário deletado com sucesso!");
                    break;

                case 5:
                    System.out.print("Digite o tamanho em cm: ");
                    double cm = scanner.nextDouble();
                    System.out.println("BR: " + SizeConversion.convertCmToBr(cm));
                    System.out.println("UK: " + SizeConversion.convertCmToUk(cm));
                    System.out.println("USA: " + SizeConversion.convertCmToUsa(cm));
                    break;

                case 0:
                    System.out.println("Saindo...");
                    break;

                default:
                    System.out.println("Opção inválida!");
            }

        } while (option != 0);

        scanner.close();
    }
}
