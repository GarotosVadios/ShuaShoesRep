package shuashoes;
public class User {
    private int id;
    private String nome;
    private String email;
    private String senha;
    private String cpf;
    private String endereco;
    private double tamanhoPadrao;

    // Construtores, getters e setters
    public User() {}

    public User(String nome, String email, String senha, String cpf, String endereco, double tamanhoPadrao) {
        this.nome = nome;
        this.email = email;
        this.senha = senha;
        this.cpf = cpf;
        this.endereco = endereco;
        this.tamanhoPadrao = tamanhoPadrao;
    }

    // Getters e Setters

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public double getTamanhoPadrao() {
        return tamanhoPadrao;
    }

    public void setTamanhoPadrao(double tamanhoPadrao) {
        this.tamanhoPadrao = tamanhoPadrao;
    }

    @Override
    public String toString() {
        return "User [id=" + id + ", nome=" + nome + ", email=" + email + ", cpf=" + cpf +
                ", endereco=" + endereco + ", tamanhoPadrao=" + tamanhoPadrao + "]";
    }
}
